import React, { useState } from 'react'
import Header from './components/Header'
import Footer from './components/Footer'
import Hero from './components/Hero'
import NewsSection from './components/NewsSection'
import ProductionsSection from './components/ProductionsSection'
import ContactSection from './components/ContactSection'
import { AnimatePresence, motion } from 'framer-motion'

export default function App(){
  const [route, setRoute] = useState('home')

  return (
    <div className="min-h-screen flex flex-col bg-unebGray text-gray-900">
      <Header onNavigate={setRoute} />

      <main className="flex-1">
        <AnimatePresence mode="wait">
          {route === 'home' && (
            <motion.div key="home" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:0.5}}>
              <Hero onExplore={()=>setRoute('news')} />
              <section className="container mx-auto px-4 -mt-24 relative z-10">
                <div className="grid gap-8 lg:grid-cols-3">
                  <NewsSection compact onOpenAll={()=>setRoute('news')} />
                  <ProductionsSection compact onOpenAll={()=>setRoute('productions')} />
                  <ContactSection compact onOpenContact={()=>setRoute('contact')} />
                </div>
              </section>
            </motion.div>
          )}

          {route === 'news' && (
            <motion.div key="news" initial={{x:50, opacity:0}} animate={{x:0,opacity:1}} exit={{x:-50, opacity:0}} transition={{duration:0.45}}>
              <section className="container mx-auto px-4 py-12">
                <h2 className="text-3xl font-bold mb-6">Notícias</h2>
                <NewsSection full />
              </section>
            </motion.div>
          )}

          {route === 'productions' && (
            <motion.div key="productions" initial={{y:30, opacity:0}} animate={{y:0,opacity:1}} exit={{y:-30, opacity:0}} transition={{duration:0.45}}>
              <section className="container mx-auto px-4 py-12">
                <h2 className="text-3xl font-bold mb-6">Produções</h2>
                <ProductionsSection full />
              </section>
            </motion.div>
          )}

          {route === 'contact' && (
            <motion.div key="contact" initial={{scale:0.98, opacity:0}} animate={{scale:1,opacity:1}} exit={{scale:0.98, opacity:0}} transition={{duration:0.35}}>
              <section className="container mx-auto px-4 py-12">
                <h2 className="text-3xl font-bold mb-6">Fale com a Agência</h2>
                <ContactSection full />
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  )
}
