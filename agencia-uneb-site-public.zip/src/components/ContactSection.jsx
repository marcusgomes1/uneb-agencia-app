import React, { useState } from 'react'
import { motion } from 'framer-motion'

export default function ContactSection({ compact=false, onOpenContact }){
  const [sent, setSent] = useState(false)

  function handleSubmit(e){
    e.preventDefault()
    const data = Object.fromEntries(new FormData(e.target))
    fetch('/api/solicitacao', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) })
      .then(r=>r.json()).then(()=>setSent(true)).catch(()=>setSent(true))
  }

  if (compact) {
    return (
      <motion.div className="bg-white rounded-xl shadow card p-4" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.45}}>
        <h3 className="font-semibold text-lg">Solicitar serviço</h3>
        <p className="text-sm text-gray-600 mt-2">Envie um briefing e nossa equipe retornará com orçamento e cronograma.</p>
        <div className="mt-4 text-right">
          <button onClick={onOpenContact} className="px-3 py-2 bg-unebBlue text-white rounded">Abrir formulário</button>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div className="bg-white rounded-xl shadow card p-4 max-w-3xl" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.45}}>
      {sent ? (
        <div className="p-6 text-center">
          <h4 className="font-semibold">Obrigado!</h4>
          <p className="text-sm text-gray-600">Recebemos seu briefing. Em breve entraremos em contato.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="grid gap-3">
          <label className="text-sm">Nome ou projeto
            <input name="nome" required className="w-full mt-1 p-2 border rounded" />
          </label>
          <label className="text-sm">Email
            <input name="email" type="email" required className="w-full mt-1 p-2 border rounded" />
          </label>
          <label className="text-sm">Descrição / Brief
            <textarea name="descricao" required className="w-full mt-1 p-2 border rounded h-28" />
          </label>
          <div className="flex justify-end">
            <button type="submit" className="px-4 py-2 bg-unebGold text-white rounded">Enviar</button>
          </div>
        </form>
      )}
    </motion.div>
  )
}
