import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

export default function NewsSection({ compact = false, onOpenAll }){
  const [news, setNews] = useState([])

  useEffect(()=>{
    fetch('/api/noticias').then(r=>r.json()).then(setNews).catch(()=>{
      setNews([
        { id:1, title:'Nova campanha institucional', excerpt:'Lançamento da campanha...', date:'2025-10-15', thumb:'https://picsum.photos/seed/n1/600/360' },
        { id:2, title:'Podcast: Vozes do Campus', excerpt:'Episódio sobre extensão...', date:'2025-09-22', thumb:'https://picsum.photos/seed/n2/600/360' }
      ])
    })
  },[])

  return (
    <motion.div className="bg-white rounded-xl shadow card p-4" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.45}}>
      <h3 className="font-semibold text-lg">Últimas notícias</h3>
      <ul className="mt-3 space-y-3">
        {(news.slice(0, compact?3:20) || []).map(n => (
          <li key={n.id} className="flex gap-3">
            <img src={n.thumb} alt={n.title} className="w-28 h-20 object-cover rounded" />
            <div>
              <div className="font-medium">{n.title}</div>
              <div className="text-xs text-gray-500">{n.date}</div>
              <p className="text-sm text-gray-600 mt-1">{n.excerpt}</p>
            </div>
          </li>
        ))}
      </ul>
      {onOpenAll && <div className="mt-4 text-right"><button onClick={onOpenAll} className="text-unebBlue text-sm">Ver todas</button></div>}
    </motion.div>
  )
}
