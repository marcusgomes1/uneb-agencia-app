import React from 'react'
import { motion } from 'framer-motion'

// VIDEO_ID set to TV UNEB promotional video (8ugr477_Jw0)
const VIDEO_ID = '8ugr477_Jw0'

export default function Hero({ onExplore }){
  return (
    <section className="relative w-full h-[80vh] overflow-hidden">
      <div aria-hidden className="absolute inset-0 -z-10">
        <iframe
          title="Vídeo institucional"
          className="w-full h-full pointer-events-none"
          src={`https://www.youtube.com/embed/${VIDEO_ID}?autoplay=1&mute=1&controls=0&showinfo=0&rel=0&loop=1&playlist=${VIDEO_ID}&modestbranding=1`}
          frameBorder="0"
          allow="autoplay; encrypted-media; picture-in-picture"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white/80"></div>
      </div>

      <div className="container mx-auto h-full flex items-center px-4">
        <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:0.8}} className="max-w-2xl">
          <h1 className="text-4xl lg:text-6xl font-bold leading-tight text-white drop-shadow">Agência de Comunicação<br/><span className="text-unebGold">UNEB</span></h1>
          <p className="mt-4 text-lg text-white/90 max-w-xl drop-shadow">Hipermídia, formação e produção institucional. Conteúdos multimídia que aproximam a universidade da sociedade.</p>
          <div className="mt-6 flex gap-3">
            <button onClick={onExplore} className="px-5 py-3 bg-unebGold rounded-md font-semibold shadow">Explorar conteúdos</button>
            <a href="#" className="px-5 py-3 border rounded-md text-white/90">Ver portfólio</a>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2">
        <div className="flex flex-col items-center text-white/80">
          <div className="w-7 h-11 border-2 border-white/80 rounded-2xl flex items-start justify-center p-1">
            <div className="w-1 h-1 rounded-full bg-white/80 animate-bounce" />
          </div>
          <small className="mt-2 text-xs">scroll</small>
        </div>
      </div>
    </section>
  )
}
