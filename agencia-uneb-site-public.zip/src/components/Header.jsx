import React, { useState } from 'react'
import { Menu } from 'lucide-react'

export default function Header({ onNavigate }){
  const [open, setOpen] = useState(false)
  return (
    <header className="fixed top-4 left-0 right-0 z-50">
      <div className="container mx-auto px-4">
        <div className="backdrop-blur bg-white/60 rounded-xl shadow-md flex items-center justify-between p-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-lg bg-unebBlue flex items-center justify-center text-white font-bold text-lg">A</div>
            <div>
              <div className="text-sm font-bold">Agência de Comunicação</div>
              <div className="text-xs text-gray-600">UNEB — Produção & Formação</div>
            </div>
          </div>

          <nav className="hidden md:flex gap-6 items-center">
            <button onClick={()=>onNavigate('home')} className="text-sm font-medium hover:text-unebBlue">Home</button>
            <button onClick={()=>onNavigate('news')} className="text-sm font-medium hover:text-unebBlue">Notícias</button>
            <button onClick={()=>onNavigate('productions')} className="text-sm font-medium hover:text-unebBlue">Produções</button>
            <button onClick={()=>onNavigate('contact')} className="text-sm font-medium hover:text-unebBlue">Contato</button>
            <a href="#" className="px-3 py-1 bg-unebGold text-white rounded-md text-sm font-semibold shadow-sm">Solicitar</a>
          </nav>

          <div className="md:hidden">
            <button aria-label="Abrir menu" onClick={()=>setOpen(!open)} className="p-2 rounded-md">
              <Menu size={18} />
            </button>
          </div>
        </div>

        {open && (
          <div className="mt-2 bg-white/90 rounded-lg p-3 shadow-md md:hidden">
            <ul className="flex flex-col gap-2">
              <li><button onClick={()=>{onNavigate('home'); setOpen(false)}} className="text-left">Home</button></li>
              <li><button onClick={()=>{onNavigate('news'); setOpen(false)}} className="text-left">Notícias</button></li>
              <li><button onClick={()=>{onNavigate('productions'); setOpen(false)}} className="text-left">Produções</button></li>
              <li><button onClick={()=>{onNavigate('contact'); setOpen(false)}} className="text-left">Contato</button></li>
            </ul>
          </div>
        )}
      </div>
    </header>
  )
}
