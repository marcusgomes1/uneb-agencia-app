import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

export default function ProductionsSection({ compact=false, onOpenAll }){
  const [items, setItems] = useState([])
  useEffect(()=>{
    fetch('/api/producoes').then(r=>r.json()).then(setItems).catch(()=>{
      setItems([
        { id:1, title:'Mostra audiovisual UNEB', type:'Vídeo', thumb:'https://picsum.photos/seed/p1/800/450' },
        { id:2, title:'Podcast: Educação e Território', type:'Podcast', thumb:'https://picsum.photos/seed/p2/800/450' }
      ])
    })
  },[])

  return (
    <motion.div className="bg-white rounded-xl shadow card p-4" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.45}}>
      <h3 className="font-semibold text-lg">Produções</h3>
      <div className="mt-3 grid gap-3">
        {(items.slice(0, compact?2:12) || []).map(i => (
          <article key={i.id} className="flex gap-3 items-center">
            <img src={i.thumb} alt={i.title} className="w-28 h-20 object-cover rounded" />
            <div>
              <div className="font-medium">{i.title}</div>
              <div className="text-xs text-gray-500">{i.type}</div>
            </div>
          </article>
        ))}
      </div>
      {onOpenAll && <div className="mt-4 text-right"><button onClick={onOpenAll} className="text-unebBlue text-sm">Ver tudo</button></div>}
    </motion.div>
  )
}
