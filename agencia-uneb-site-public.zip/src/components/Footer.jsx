import React from 'react'
export default function Footer(){
  return (
    <footer className="bg-white border-t mt-12">
      <div className="container mx-auto px-4 py-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <div className="font-semibold">Agência de Comunicação — UNEB</div>
          <small className="text-xs text-gray-600">Universidade do Estado da Bahia</small>
        </div>
        <div className="text-sm text-gray-600">© {new Date().getFullYear()} • Todos os direitos reservados</div>
        <nav className="flex gap-3">
          <a className="text-sm text-unebBlue">Instagram</a>
          <a className="text-sm text-unebBlue">YouTube</a>
          <a className="text-sm text-unebBlue">Twitter</a>
        </nav>
      </div>
    </footer>
  )
}
