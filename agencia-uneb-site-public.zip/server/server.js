import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

const noticias = [
  { id: 1, titulo: 'Nova campanha institucional', resumo: 'A UNEB lança nova campanha...', data: '2025-10-15' },
  { id: 2, titulo: 'Podcast Comunicação & Extensão', resumo: 'Novo episódio sobre mídia universitária...', data: '2025-09-22' }
];

const producoes = [
  { id: 1, tipo: 'vídeo', titulo: 'Mostra audiovisual UNEB', url: 'https://youtube.com/embed/xxxx' },
  { id: 2, tipo: 'podcast', titulo: 'Educomunicação em foco', url: 'https://open.spotify.com/embed/xxxx' }
];

app.get('/api/noticias', (req, res) => res.json(noticias));
app.get('/api/producoes', (req, res) => res.json(producoes));

app.post('/api/solicitacao', (req, res) => {
  const { nome, email, descricao } = req.body;
  console.log('Nova solicitação:', nome, email, descricao);
  res.status(201).json({ mensagem: 'Solicitação recebida com sucesso!' });
});

const PORT = 4000;
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
